import discord
from discord import app_commands
import os
import sys
import asyncio
import json
import time
import uuid
import tempfile
from datetime import datetime
from curl_cffi.requests import AsyncSession

from algorithms.mines import get_mines_prediction
from algorithms.towers import get_towers_prediction

if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

DB_FILE = "database.json"
OWNER_ID = 1480833706636611678
ADMIN_ROLES = [1491470886224531667, 1496150466374013079]
ALLOWED_CHANNELS = [1496136776786514094, 1495371571878039564]
ALLOWED_GUILDS = [1487809500344746004, 1409975989467091026]

# Headers from your latest verified method
REFRESH_HEADERS = {
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.8',
    'origin': 'https://bloxflip.com',
    'priority': 'u=1, i',
    'referer': 'https://bloxflip.com/',
    'sec-ch-ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Brave";v="146"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
}

def log_console(category, message):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] [{category}] {message}")

def obfuscate_token(token):
    return "-".join([str(ord(c) * 67) for c in token])

def deobfuscate_token(hashed):
    if not isinstance(hashed, str) or "-" not in hashed: return hashed
    try:
        return "".join([chr(int(x) // 67) for x in hashed.split("-")])
    except Exception:
        return hashed

def get_tokens(user_data):
    """Return (app_at, app_rt) handling both old (jwt/refresh_token) and new (app_at/app_rt) key names."""
    app_at = user_data.get("app_at") or user_data.get("jwt", "")
    app_rt = deobfuscate_token(user_data.get("app_rt") or user_data.get("refresh_token", ""))
    return app_at, app_rt

def load_db():
    try:
        if os.path.exists(DB_FILE):
            with open(DB_FILE, "r") as f:
                return json.load(f)
    except Exception as e:
        log_console("ERROR", f"load_db failed: {e}")
    return {}

def save_db(data):
    try:
        db_dir = os.path.dirname(os.path.abspath(DB_FILE))
        with tempfile.NamedTemporaryFile("w", dir=db_dir, delete=False, suffix=".tmp") as f:
            json.dump(data, f, indent=4)
            tmp_path = f.name
        os.replace(tmp_path, DB_FILE)
    except Exception as e:
        log_console("ERROR", f"save_db failed: {e}")

PLAN_DURATIONS = {
    "weekly": 7 * 24 * 3600,
    "monthly": 30 * 24 * 3600,
    "lifetime": None,
}

def has_active_plan(user_id):
    db = load_db()
    user_data = db.get(str(user_id))
    if not user_data: return False, "No active plan found. Contact an admin to get access."
    plan = user_data.get("plan")
    if not plan: return False, "No active plan found. Contact an admin to get access."
    expires_at = user_data.get("expires_at")
    if expires_at is not None and time.time() > expires_at:
        return False, "Your plan has expired. Contact an admin to renew."
    return True, None

def format_plan_info(user_data):
    plan = user_data.get("plan")
    if not plan:
        return "No plan", "N/A"
    expires_at = user_data.get("expires_at")
    if expires_at is None:
        status = "Lifetime"
        expiry_str = "Never"
    else:
        remaining = expires_at - time.time()
        if remaining <= 0:
            return plan.capitalize(), "Expired"
        days = int(remaining // 86400)
        hours = int((remaining % 86400) // 3600)
        expiry_str = f"<t:{int(expires_at)}:R> ({days}d {hours}h left)"
        status = plan.capitalize()
    return status, expiry_str

def is_admin(interaction: discord.Interaction):
    if interaction.user.id == OWNER_ID: return True
    if interaction.user.guild_permissions.administrator: return True
    if hasattr(interaction.user, 'roles'):
        for role in interaction.user.roles:
            if role.id in ADMIN_ROLES: return True
    return False

def is_allowed_channel(interaction: discord.Interaction):
    return interaction.channel_id in ALLOWED_CHANNELS

async def refresh_bloxflip_session(app_rt, current_app_at=None):
    try:
        log_console("SYSTEM", "Attempting IOS-Safari session refresh...")
        url = "https://bloxflip.com/api/auth/fusionauth/refresh"

        async with AsyncSession() as s:
            s.cookies.set("app.rt", app_rt, domain="bloxflip.com")
            resp = await s.post(url, headers=REFRESH_HEADERS, impersonate="safari15_5", timeout=15)

            new_at = None
            for cookie_header in resp.headers.get_list("Set-Cookie"):
                if "app.at=" in cookie_header:
                    new_at = cookie_header.split("app.at=")[1].split(";")[0]
                    break

            if not new_at:
                new_at = s.cookies.get("app.at")

            if new_at and new_at != "undefined" and new_at != current_app_at:
                log_console("SYSTEM", "IOS-Safari Refresh SUCCESS.")
                return new_at
            else:
                log_console("API_ERROR", f"Refresh failed to return new app.at (Status: {resp.status_code})")
    except Exception as e:
        log_console("ERROR", f"refresh_session: {e}")
    return None

async def get_user_profile(app_at, app_rt=None, depth=0):
    if depth > 2: return None
    try:
        url = "https://bloxflip.com/api/user"
        headers = REFRESH_HEADERS.copy()
        headers["Cookie"] = f"app.at={app_at}" + (f"; app.rt={app_rt}" if app_rt else "")
        headers["x-currency"] = "FLIPCOINS"

        async with AsyncSession() as s:
            resp = await s.get(url, headers=headers, impersonate="safari15_5", timeout=15)
            if resp.status_code == 403:
                data = resp.json()
                if data.get("jwtRefreshNeeded") and app_rt:
                    log_console("SYSTEM", "JWT Expired, triggering iOS Refresh...")
                    new_jwt = await refresh_bloxflip_session(app_rt, app_at)
                    if new_jwt:
                        return await get_user_profile(new_jwt, app_rt, depth + 1)

            if resp.status_code == 200:
                return resp.json()
    except Exception as e:
        log_console("ERROR", f"get_user_profile: {e}")
    return None

async def get_roblox_avatar(roblox_id):
    try:
        url = f"https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds={roblox_id}&size=150x150&format=Png"
        async with AsyncSession() as s:
            resp = await s.get(url, timeout=5)
            if resp.status_code == 200:
                return resp.json().get("data", [{}])[0].get("imageUrl")
    except Exception:
        pass
    return None

async def get_game_data(app_at, game_type, app_rt=None):
    try:
        url = f"https://bloxflip.com/api/games/{game_type}"
        headers = REFRESH_HEADERS.copy()
        headers["Cookie"] = f"app.at={app_at}" + (f"; app.rt={app_rt}" if app_rt else "")
        async with AsyncSession() as s:
            resp = await s.get(url, headers=headers, impersonate="safari15_5", timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("hasGame"): return data.get("game", {}).get("uuid")
    except Exception:
        pass
    return None

async def get_history_str(app_at, game_type, app_rt=None):
    try:
        url = f"https://bloxflip.com/api/games/{game_type}/history"
        headers = REFRESH_HEADERS.copy()
        headers["Cookie"] = f"app.at={app_at}" + (f"; app.rt={app_rt}" if app_rt else "")
        async with AsyncSession() as s:
            resp = await s.get(url, headers=headers, impersonate="safari15_5", timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                history = data.get("history", [])
                games = []
                if game_type == "mines":
                    for g in history[:15]:
                        mine_indices = g.get("mineIndices", [])
                        games.append(",".join(map(str, mine_indices)))
                elif game_type == "towers":
                    for g in history[:15]:
                        tower_levels = g.get("towerLevels", [])
                        games.append(json.dumps(tower_levels))
                return "|".join(games)
    except Exception:
        pass
    return ""

class LimitsCommandTree(app_commands.CommandTree):
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.guild_id not in ALLOWED_GUILDS:
            await interaction.response.send_message(
                embed=create_error_embed("This bot is not authorized in this server."),
                ephemeral=True
            )
            return False
        return True

class LimitsBot(discord.Client):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        super().__init__(intents=intents)
        self.tree = LimitsCommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()

client = LimitsBot()

@client.event
async def on_ready():
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="Limits"))
    log_console("SYSTEM", f"Logged in as {client.user}")

@client.tree.command(name="how-to-link", description="Tutorial on how to link your Bloxflip account")
async def how_to_link(interaction: discord.Interaction):
    try:
        log_console("COMMAND", f"/how-to-link used by {interaction.user}")
        if not is_allowed_channel(interaction):
            await interaction.response.send_message(embed=create_error_embed("Command not allowed in this channel."), ephemeral=True)
            return

        # --- Desktop Guide ---
        desktop_embed = discord.Embed(
            title="Limits Predictor | How to Link - Desktop",
            description=(
                "You need two cookies from Bloxflip: **`app.rt`** (refresh token) and **`app.at`** (access token).\n"
                "This takes about 1 minute and only needs to be done once.\n\u200b"
            ),
            color=0xFFFFFF
        )
        desktop_embed.add_field(
            name="Step 1 - Open Bloxflip & Log In",
            value=(
                "Go to [bloxflip.com](https://bloxflip.com) in your browser and make sure you are **logged in** with Roblox.\n"
                "> ⚠️ If you just logged in, wait for the page to fully load before continuing."
            ),
            inline=False
        )
        desktop_embed.add_field(
            name="Step 2 - Open DevTools & Navigate to Cookies",
            value=(
                "1. Press **F12** (or right-click anywhere → *Inspect*) to open DevTools.\n"
                "2. Click the **Application** tab at the top of DevTools.\n"
                "   → If you don't see it, click the **`»`** arrow to find hidden tabs.\n"
                "3. In the left sidebar, expand **Cookies** → click `https://bloxflip.com`.\n"
                "4. You'll see a list of cookies - find these two:\n"
                "   • `app.at` - your **Access Token**\n"
                "   • `app.rt` - your **Refresh Token**"
            ),
            inline=False
        )
        desktop_embed.add_field(
            name="Step 3 - Copy Both Values",
            value=(
                "Click on `app.at` in the list - the full value appears at the bottom of the panel.\n"
                "Copy it, then do the same for `app.rt`.\n"
                "> ⚠️ These are long strings. Make sure you copy the **entire** value with no missing characters."
            ),
            inline=False
        )
        desktop_embed.add_field(
            name="Step 4 - Run the Link Command",
            value=(
                "Use the following slash command in Discord:\n"
                "```/link app-rt:YOUR_RT app-at:YOUR_AT```\n"
                "Paste the cookie values in the correct fields."
            ),
            inline=False
        )
        desktop_embed.add_field(
            name="🔒 Security Note",
            value=(
                "Your refresh token is **encrypted** before being stored and is never shared.\n"
                "It is only used to maintain your Bloxflip session for predictions."
            ),
            inline=False
        )
        desktop_embed.add_field(
            name="❓ Troubleshooting",
            value=(
                "• **Link failed** - Make sure you copied both full values with no spaces.\n"
                "• **Cookies missing** - Log out of Bloxflip, log back in, then retry.\n"
                "• **Session keeps expiring** - Your `app.rt` may be wrong; re-copy it carefully.\n"
                "• Still stuck? Ask in the support channel."
            ),
            inline=False
        )
        desktop_embed.set_footer(text="Limits Predictor • See next embed for mobile instructions")

        # --- Mobile Guide ---
        mobile_embed = discord.Embed(
            title="Limits Predictor | How to Link - Mobile",
            description=(
                "Standard mobile browsers don't expose cookies directly - use one of the methods below.\n\u200b"
            ),
            color=0xFFFFFF
        )
        mobile_embed.add_field(
            name="Method A - Kiwi Browser (Android, Easiest)",
            value=(
                "1. Install **Kiwi Browser** from the Play Store - it has full desktop DevTools.\n"
                "2. Go to [bloxflip.com](https://bloxflip.com) and log in.\n"
                "3. Tap the **⋮ menu** → *Developer Tools*.\n"
                "4. Tap the **Application** tab → **Cookies** → `https://bloxflip.com`.\n"
                "5. Find `app.at` and `app.rt` - tap each one to see the full value and copy it."
            ),
            inline=False
        )
        mobile_embed.add_field(
            name="Method B - Safari Web Inspector (iPhone/iPad + Mac)",
            value=(
                "1. On your **Mac**: Safari → Settings → Advanced → enable *Show Develop menu*.\n"
                "2. On your **iPhone/iPad**: Settings → Safari → Advanced → enable *Web Inspector*.\n"
                "3. Connect your device to your Mac via USB.\n"
                "4. Open [bloxflip.com](https://bloxflip.com) in Safari on your iOS device and log in.\n"
                "5. On your Mac: **Develop** menu → select your device → the Bloxflip page.\n"
                "6. Go to **Storage** → **Cookies** → find `app.at` and `app.rt` and copy their values."
            ),
            inline=False
        )
        mobile_embed.add_field(
            name="Method C - Use a PC (Recommended if Available)",
            value=(
                "The desktop method is the easiest overall. If you have access to any computer,\n"
                "follow the Desktop guide in the embed above - the tokens don't change unless you log out."
            ),
            inline=False
        )
        mobile_embed.add_field(
            name="Step - Run the Link Command",
            value=(
                "Once you have both values, run this in Discord:\n"
                "```/link app-rt:YOUR_RT app-at:YOUR_AT```"
            ),
            inline=False
        )
        mobile_embed.set_footer(text="Limits Predictor • Mobile guide")

        await interaction.response.send_message(embeds=[desktop_embed, mobile_embed], ephemeral=True)
    except Exception as e:
        log_console("ERROR", f"how-to-link: {e}")
        await interaction.response.send_message(embed=create_error_embed("Error displaying tutorial."), ephemeral=True)

@client.tree.command(name="link", description="Link your Bloxflip account")
@app_commands.rename(app_rt="app-rt", app_at="app-at")
@app_commands.describe(app_rt="Your Bloxflip Refresh Token (app.rt)", app_at="Your Bloxflip Access Token (app.at)")
async def link(interaction: discord.Interaction, app_rt: str, app_at: str):
    try:
        if not is_allowed_channel(interaction):
            await interaction.response.send_message(embed=create_error_embed("Command not allowed."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)

        # Test the provided session immediately
        profile_data = await get_user_profile(app_at, app_rt)
        jwt = app_at

        if not profile_data:
            log_console("SYSTEM", "Provided app.at rejected, attempting iOS Refresh...")
            jwt = await refresh_bloxflip_session(app_rt, app_at)
            if jwt: profile_data = await get_user_profile(jwt, app_rt)

        if not profile_data:
            await interaction.followup.send(embed=create_error_embed("Failed to fetch profile. Make sure you copied both tokens correctly."), ephemeral=True)
            return

        prof = profile_data.get("user", profile_data.get("profile", {}))
        db = load_db()
        existing = db.get(str(interaction.user.id), {})
        db[str(interaction.user.id)] = {
            "roblox_id": str(prof.get("robloxId", "Unknown")),
            "roblox_username": prof.get("robloxUsername", "Unknown"),
            "app_rt": obfuscate_token(app_rt),
            "app_at": jwt,
            "linked_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "plan": existing.get("plan"),
            "expires_at": existing.get("expires_at"),
            "plan_assigned_at": existing.get("plan_assigned_at"),
            "plan_assigned_by": existing.get("plan_assigned_by"),
        }
        save_db(db)
        embed = discord.Embed(title="Limits Predictor | Account Linked", description=f"Successfully linked to **{prof.get('robloxUsername')}**!", color=0xFFFFFF)
        await interaction.followup.send(embed=embed, ephemeral=True)
    except Exception as e:
        log_console("ERROR", f"link: {e}")
        await interaction.followup.send(embed=create_error_embed("Link failed."), ephemeral=True)

@client.tree.command(name="profile", description="View your Bloxflip profile")
async def profile(interaction: discord.Interaction):
    try:
        allowed, msg = has_active_plan(interaction.user.id)
        if not allowed:
            await interaction.response.send_message(embed=create_error_embed(msg), ephemeral=True)
            return
        db = load_db()
        user_data = db.get(str(interaction.user.id))
        if not user_data:
            await interaction.response.send_message(embed=create_error_embed("Link your account first with `/link`."), ephemeral=True)
            return
        await interaction.response.defer()

        app_at, app_rt = get_tokens(user_data)
        data = await get_user_profile(app_at, app_rt)
        if not data:
            await interaction.followup.send(embed=create_error_embed("Failed to retrieve profile. Try `/link` again."), ephemeral=True)
            return

        log_console("DEBUG", f"Profile raw keys: {list(data.keys())}")

        prof = data.get("user", data.get("profile", {}))

        # ── Identity ──────────────────────────────────────────────
        roblox_username = prof.get("robloxUsername") or prof.get("username", "N/A")
        roblox_id       = prof.get("robloxId", "N/A")

        # ── Balance ───────────────────────────────────────────────
        wallet_data = data.get("wallet", {})
        balance = float(wallet_data.get("balances", {}).get("FLIPCOINS", 0))

        # ── Rakeback ──────────────────────────────────────────────
        rakeback_data = wallet_data.get("rakeback", {})
        rakeback_claimable = rakeback_data.get("claimable")
        rakeback_available = float(rakeback_claimable) if rakeback_claimable is not None else None

        # ── Level / XP ────────────────────────────────────────────
        level = prof.get("level")
        next_level_pct = prof.get("nextLevelPercentage")

        # ── Stats ─────────────────────────────────────────────────
        stats         = data.get("stats") or {}
        total_wagered = float(stats.get("totalPlayed") or 0)
        total_deposited = float(stats.get("totalDeposited") or 0)
        total_withdrawn = float(stats.get("totalWithdrawn") or 0)

        # ── Misc ──────────────────────────────────────────────────
        created_at     = prof.get("createdAt") or prof.get("created_at")
        affiliate_raw  = prof.get("affiliate") or prof.get("affiliateCode")
        affiliate_code = affiliate_raw.get("code") if isinstance(affiliate_raw, dict) else affiliate_raw
        is_banned      = prof.get("banned", False)
        muted_until    = prof.get("mutedUntil") or prof.get("muted")

        # ── Plan ──────────────────────────────────────────────────
        plan_name, expiry_str = format_plan_info(user_data)

        # ── Roblox avatar ─────────────────────────────────────────
        avatar_url = await get_roblox_avatar(roblox_id)

        # ── Build embed ───────────────────────────────────────────
        status_parts = []
        if is_banned: status_parts.append("🔨 Banned")
        if muted_until: status_parts.append("🔇 Muted")

        embed = discord.Embed(
            title=f"{roblox_username}",
            description=("  ".join(status_parts) if status_parts else None),
            color=0xFFFFFF
        )
        if avatar_url:
            embed.set_thumbnail(url=avatar_url)

        # Row 1 -Identity
        embed.add_field(name="Roblox Username", value=f"`{roblox_username}`", inline=True)
        embed.add_field(name="Roblox ID", value=f"`{roblox_id}`", inline=True)
        embed.add_field(name="​", value="​", inline=True)

        # Row 2 -Wallet
        embed.add_field(name="Balance", value=f"`{balance:,.2f}` FC", inline=True)
        if rakeback_available is not None:
            embed.add_field(name="Rakeback Available", value=f"`{rakeback_available:,.2f}` FC", inline=True)
            embed.add_field(name="​", value="​", inline=True)

        # Row 3 -Level / XP
        if level is not None:
            embed.add_field(name="Level", value=f"`{level}`", inline=True)
            if next_level_pct is not None:
                embed.add_field(name="Next Level", value=f"`{next_level_pct:.1f}%`", inline=True)
            embed.add_field(name="​", value="​", inline=True)

        # Row 4 -Stats
        if total_wagered:
            embed.add_field(name="Total Played", value=f"`{total_wagered:,.2f}` FC", inline=True)
        if total_deposited:
            embed.add_field(name="Total Deposited", value=f"`{total_deposited:,.2f}` FC", inline=True)
        if total_withdrawn:
            embed.add_field(name="Total Withdrawn", value=f"`{total_withdrawn:,.2f}` FC", inline=True)

        # Row 5 -Misc
        if created_at:
            try:
                dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                embed.add_field(name="Account Created", value=f"<t:{int(dt.timestamp())}:D>", inline=True)
            except:
                embed.add_field(name="Account Created", value=f"`{created_at}`", inline=True)
        if affiliate_code:
            embed.add_field(name="Affiliate Code", value=f"`{affiliate_code}`", inline=True)

        # Row 6 -Subscription
        embed.add_field(name="​", value="─────────────────", inline=False)
        embed.add_field(name="Plan", value=f"`{plan_name}`", inline=True)
        embed.add_field(name="Expires", value=expiry_str, inline=True)

        embed.set_footer(text="Limits Predictor • Bloxflip Profile")
        await interaction.followup.send(embed=embed)
    except Exception as e:
        log_console("ERROR", f"profile: {e}")
        await interaction.followup.send(embed=create_error_embed("Internal error."), ephemeral=True)

COL_NAMES = ["Left", "Mid", "Right"]
METHOD_LABELS = {"booster": "Booster MAX", "ensemble": "Ensemble"}

def confidence_display(conf):
    icon = "🟢" if conf >= 80 else ("🟡" if conf >= 65 else "🔴")
    return f"{icon} `{conf:.1f}%`"

@client.tree.command(name="mines", description="Predict safe spots for your active Mines game")
@app_commands.describe(amount="Number of safe spots to predict (2–6)", method="Prediction method")
@app_commands.choices(
    amount=[app_commands.Choice(name=f"{i} Safe Spots", value=i) for i in range(2, 7)],
    method=[
        app_commands.Choice(name="Booster MAX", value="booster"),
        app_commands.Choice(name="Ensemble",    value="ensemble"),
    ]
)
async def mines(interaction: discord.Interaction, amount: int, method: str):
    try:
        allowed, msg = has_active_plan(interaction.user.id)
        if not allowed:
            await interaction.response.send_message(embed=create_error_embed(msg), ephemeral=True)
            return
        db = load_db()
        user_data = db.get(str(interaction.user.id))
        if not user_data:
            await interaction.response.send_message(embed=create_error_embed("Link your account first with `/link`."), ephemeral=True)
            return
        await interaction.response.defer()
        app_at, app_rt = get_tokens(user_data)
        game_id = await get_game_data(app_at, "mines", app_rt)
        if not game_id:
            new_at = await refresh_bloxflip_session(app_rt, app_at)
            if new_at:
                user_data["app_at"] = new_at
                db[str(interaction.user.id)] = user_data
                save_db(db)
                app_at = new_at
                game_id = await get_game_data(app_at, "mines", app_rt)
        if not game_id:
            await interaction.followup.send(embed=create_error_embed("No active Mines game found on your account."), ephemeral=True)
            return
        hist = await get_history_str(app_at, "mines", app_rt)
        pred = get_mines_prediction(method, game_id, hist, amount)
        safe = pred.get("safe", [])
        conf = pred.get("confidence", 0)
        safe_set = set(safe)

        grid_lines = []
        for row in range(5):
            cells = " ".join("⭐" if (row * 5 + col) in safe_set else " 💣" for col in range(5))
            grid_lines.append(cells)
        grid_str = "\n".join(grid_lines)

        embed = discord.Embed(title="Limits Predictor | Mines", color=0xFFFFFF)
        embed.description = grid_str
        embed.add_field(name="Safe / Mines", value=f"`{amount}` safe  ·  `{25 - amount}` mines", inline=True)
        embed.add_field(name="Method", value=f"`{METHOD_LABELS.get(method, method)}`", inline=True)
        embed.add_field(name="Confidence", value=confidence_display(conf), inline=True)
        embed.set_footer(text=f"Limits Predictor  ·  Seed: {str(game_id)[:12]}…")
        await interaction.followup.send(embed=embed)
    except Exception as e:
        log_console("ERROR", f"mines: {e}")
        await interaction.followup.send(embed=create_error_embed("Internal error."), ephemeral=True)

@client.tree.command(name="towers", description="Predict safe columns for your active Towers game")
@app_commands.describe(method="Prediction method")
@app_commands.choices(
    method=[
        app_commands.Choice(name="Booster MAX", value="booster"),
        app_commands.Choice(name="Ensemble",    value="ensemble"),
    ]
)
async def towers(interaction: discord.Interaction, method: str):
    try:
        allowed, msg = has_active_plan(interaction.user.id)
        if not allowed:
            await interaction.response.send_message(embed=create_error_embed(msg), ephemeral=True)
            return
        db = load_db()
        user_data = db.get(str(interaction.user.id))
        if not user_data:
            await interaction.response.send_message(embed=create_error_embed("Link your account first with `/link`."), ephemeral=True)
            return
        await interaction.response.defer()
        app_at, app_rt = get_tokens(user_data)
        game_id = await get_game_data(app_at, "towers", app_rt)
        if not game_id:
            new_at = await refresh_bloxflip_session(app_rt, app_at)
            if new_at:
                user_data["app_at"] = new_at
                db[str(interaction.user.id)] = user_data
                save_db(db)
                app_at = new_at
                game_id = await get_game_data(app_at, "towers", app_rt)
        if not game_id:
            await interaction.followup.send(embed=create_error_embed("No active Towers game found on your account."), ephemeral=True)
            return
        hist = await get_history_str(app_at, "towers", app_rt)
        pred = get_towers_prediction(method, game_id, hist)
        safe = pred.get("safe", [])
        conf = pred.get("confidence", 0)

        # Floor 8 at top → Floor 1 at bottom
        grid_lines = []
        for floor in range(len(safe) - 1, -1, -1):
            safe_col = min(safe[floor], 2)
            cells = " ".join("🟩" if c == safe_col else "🟥" for c in range(3))
            grid_lines.append(f"`{floor + 1}` {cells}")
        grid_str = "\n".join(grid_lines)

        embed = discord.Embed(title="Limits Predictor | Towers", color=0xFFFFFF)
        embed.description = grid_str
        embed.add_field(name="Method", value=f"`{METHOD_LABELS.get(method, method)}`", inline=True)
        embed.add_field(name="Confidence", value=confidence_display(conf), inline=True)
        embed.set_footer(text=f"Limits Predictor  ·  Seed: {str(game_id)[:12]}…")
        await interaction.followup.send(embed=embed)
    except Exception as e:
        log_console("ERROR", f"towers: {e}")
        await interaction.followup.send(embed=create_error_embed("Internal error."), ephemeral=True)

@client.tree.command(name="unrig", description="Reset your Bloxflip client seed to change game outcomes")
async def unrig(interaction: discord.Interaction):
    try:
        log_console("COMMAND", f"/unrig called by {interaction.user} (id={interaction.user.id})")
        allowed, msg = has_active_plan(interaction.user.id)
        log_console("DEBUG", f"/unrig plan check: allowed={allowed}, msg={msg}")
        if not allowed:
            await interaction.response.send_message(embed=create_error_embed(msg), ephemeral=True)
            return
        db = load_db()
        user_data = db.get(str(interaction.user.id))
        if not user_data:
            await interaction.response.send_message(embed=create_error_embed("Link your account first with `/link`."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)

        app_at, app_rt = get_tokens(user_data)

        # Proactively refresh token in case it's expired
        new_at = await refresh_bloxflip_session(app_rt, app_at)
        if new_at:
            app_at = new_at
            user_data["app_at"] = new_at
            db[str(interaction.user.id)] = user_data
            save_db(db)

        new_seed = str(uuid.uuid4())

        headers = REFRESH_HEADERS.copy()
        headers["Cookie"] = f"app.at={app_at}" + (f"; app.rt={app_rt}" if app_rt else "")
        headers["Content-Type"] = "application/json"

        async with AsyncSession() as s:
            resp = await s.post(
                "https://bloxflip.com/api/provably-fair/clientSeed",
                headers=headers,
                json={"clientSeed": new_seed},
                impersonate="safari15_5",
                timeout=15
            )

        if resp.status_code == 200:
            embed = discord.Embed(title="Limits Predictor | Unrig", color=0xFFFFFF)
            embed.add_field(name="Status", value="✅ Successfully unrigged", inline=False)
            embed.add_field(name="New Client Seed", value=f"`{new_seed}`", inline=False)
            embed.set_footer(text="Limits Predictor • Your client seed has been reset")
            log_console("COMMAND", f"/unrig used by {interaction.user} — new seed: {new_seed}")
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            await interaction.followup.send(embed=create_error_embed(f"Bloxflip rejected the request (status {resp.status_code}). Try re-linking your account."), ephemeral=True)
    except Exception as e:
        log_console("ERROR", f"unrig: {e}")
        await interaction.followup.send(embed=create_error_embed("Internal error."), ephemeral=True)

@client.tree.command(name="assign-plan", description="[Admin] Assign a subscription plan to a user")
@app_commands.describe(user="The Discord user to assign a plan to", plan="Plan type to assign")
@app_commands.choices(plan=[
    app_commands.Choice(name="Weekly (7 days)", value="weekly"),
    app_commands.Choice(name="Monthly (30 days)", value="monthly"),
    app_commands.Choice(name="Lifetime", value="lifetime"),
])
async def assign_plan(interaction: discord.Interaction, user: discord.Member, plan: str):
    try:
        if not is_admin(interaction):
            await interaction.response.send_message(embed=create_error_embed("You don't have permission to use this command."), ephemeral=True)
            return

        duration = PLAN_DURATIONS.get(plan)
        expires_at = None if duration is None else time.time() + duration

        db = load_db()
        user_data = db.get(str(user.id), {})
        user_data["plan"] = plan
        user_data["expires_at"] = expires_at
        user_data["plan_assigned_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        user_data["plan_assigned_by"] = str(interaction.user.id)
        db[str(user.id)] = user_data
        save_db(db)

        if plan == "lifetime":
            expiry_display = "Never (Lifetime)"
        else:
            expiry_display = f"<t:{int(expires_at)}:F>"

        customer_role = interaction.guild.get_role(1492799056953610370)
        if customer_role and customer_role not in user.roles:
            await user.add_roles(customer_role)

        embed = discord.Embed(title="Limits Predictor | Plan Assigned", color=0xFFFFFF)
        embed.add_field(name="User", value=user.mention, inline=True)
        embed.add_field(name="Plan", value=plan.capitalize(), inline=True)
        embed.add_field(name="Expires", value=expiry_display, inline=True)
        embed.set_footer(text=f"Assigned by {interaction.user}")
        log_console("ADMIN", f"{interaction.user} assigned {plan} plan to {user} (expires: {expiry_display})")
        await interaction.response.send_message(embed=embed)
    except Exception as e:
        log_console("ERROR", f"assign-plan: {e}")
        await interaction.response.send_message(embed=create_error_embed("Failed to assign plan."), ephemeral=True)

@client.tree.command(name="revoke-plan", description="[Admin] Revoke a user's subscription plan")
@app_commands.describe(user="The Discord user to revoke the plan from")
async def revoke_plan(interaction: discord.Interaction, user: discord.Member):
    try:
        if not is_admin(interaction):
            await interaction.response.send_message(embed=create_error_embed("You don't have permission to use this command."), ephemeral=True)
            return

        db = load_db()
        user_data = db.get(str(user.id))
        if not user_data or not user_data.get("plan"):
            await interaction.response.send_message(embed=create_error_embed(f"{user.mention} has no active plan."), ephemeral=True)
            return

        old_plan = user_data.get("plan", "unknown")
        user_data["plan"] = None
        user_data["expires_at"] = None
        user_data["plan_assigned_at"] = None
        user_data["plan_assigned_by"] = None
        db[str(user.id)] = user_data
        save_db(db)

        embed = discord.Embed(title="Limits Predictor | Plan Revoked", color=0xFFFFFF)
        embed.add_field(name="User", value=user.mention, inline=True)
        embed.add_field(name="Revoked Plan", value=old_plan.capitalize(), inline=True)
        embed.set_footer(text=f"Revoked by {interaction.user}")
        log_console("ADMIN", f"{interaction.user} revoked {old_plan} plan from {user}")
        await interaction.response.send_message(embed=embed)
    except Exception as e:
        log_console("ERROR", f"revoke-plan: {e}")
        await interaction.response.send_message(embed=create_error_embed("Failed to revoke plan."), ephemeral=True)

@client.tree.command(name="check-plan", description="[Admin] Check any user's subscription plan")
@app_commands.describe(user="The Discord user to check")
async def check_plan(interaction: discord.Interaction, user: discord.Member):
    try:
        if not is_admin(interaction):
            await interaction.response.send_message(embed=create_error_embed("You don't have permission to use this command."), ephemeral=True)
            return

        db = load_db()
        user_data = db.get(str(user.id))
        if not user_data:
            await interaction.response.send_message(embed=create_error_embed(f"{user.mention} has no linked account."), ephemeral=True)
            return

        plan_name, expiry_str = format_plan_info(user_data)
        assigned_at = user_data.get("plan_assigned_at", "N/A")
        assigned_by_id = user_data.get("plan_assigned_by")
        assigned_by = f"<@{assigned_by_id}>" if assigned_by_id else "N/A"

        embed = discord.Embed(title="Limits Predictor | Plan Info", color=0xFFFFFF)
        embed.add_field(name="User", value=user.mention, inline=True)
        embed.add_field(name="Plan", value=plan_name, inline=True)
        embed.add_field(name="Expires", value=expiry_str, inline=True)
        embed.add_field(name="Assigned At", value=assigned_at, inline=True)
        embed.add_field(name="Assigned By", value=assigned_by, inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)
    except Exception as e:
        log_console("ERROR", f"check-plan: {e}")
        await interaction.response.send_message(embed=create_error_embed("Failed to check plan."), ephemeral=True)

@client.tree.command(name="my-plan", description="View your current subscription plan")
async def my_plan(interaction: discord.Interaction):
    try:
        db = load_db()
        user_data = db.get(str(interaction.user.id))
        if not user_data:
            await interaction.response.send_message(embed=create_error_embed("You don't have a linked account. Use /link first."), ephemeral=True)
            return

        plan_name, expiry_str = format_plan_info(user_data)

        plan = user_data.get("plan")
        expires_at = user_data.get("expires_at")
        active = bool(plan) and (expires_at is None or time.time() <= expires_at)
        status_icon = "✅" if active else "❌"

        embed = discord.Embed(title="Limits Predictor | My Plan", color=0xFFFFFF)
        embed.add_field(name="Status", value=f"{status_icon} {'Active' if active else 'Inactive'}", inline=True)
        embed.add_field(name="Plan", value=plan_name, inline=True)
        embed.add_field(name="Expires", value=expiry_str, inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)
    except Exception as e:
        log_console("ERROR", f"my-plan: {e}")
        await interaction.response.send_message(embed=create_error_embed("Failed to retrieve plan info."), ephemeral=True)

def create_error_embed(message):
    embed = discord.Embed(title="Limits Predictor | Error", description=f"❌ {message}", color=0xFFFFFF)
    return embed

if __name__ == "__main__":
    p = "token.txt"
    if os.path.exists(p):
        with open(p, "r") as f: client.run(f.read().strip())
    else: log_console("SYSTEM", "token.txt not found")