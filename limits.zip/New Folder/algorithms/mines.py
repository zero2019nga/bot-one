import numpy as np
import hashlib
import importlib
import json

def get_mines_prediction(method, game_id, history_str, amount):
    try:
        amount = max(1, min(24, int(amount)))
        history_grid = np.zeros((15, 25))
        if history_str:
            games = str(history_str).split('|')
            for i, g in enumerate(games[:15]):
                try:
                    locs = [int(x) for x in g.split(',') if x]
                    for l in locs:
                        if 0 <= l < 25: history_grid[i][l] = 1
                except: continue
        seed_str = f"{game_id}:{method}"
        seed_val = int(hashlib.md5(seed_str.encode()).hexdigest()[:8], 16) % 2**32
        rng = np.random.RandomState(seed_val)
        try:
            algo_module = importlib.import_module(f"algorithms.mines_{method}")
            weights = algo_module.predict(rng, history_grid)
        except:
            weights = np.mean(history_grid, axis=0)
        final_scores = (weights * 0.7) + (rng.rand(25) * 0.3)
        safe_spots = np.argsort(final_scores)[:amount].tolist()
        return {"success": True, "safe": safe_spots, "confidence": round(float(rng.uniform(60, 75)), 2)}
    except:
        return {"success": False, "error": "Prediction Engine Error"}

def get_towers_prediction(method, game_id, history_str):
    try:
        heatmap = np.zeros((8, 3))
        if history_str:
            games = str(history_str).split('|')
            for g in games[:15]:
                try:
                    levels = json.loads(g)
                    for r, row_vals in enumerate(levels):
                        if r < 8:
                            for c, val in enumerate(row_vals):
                                if val == 1: heatmap[r][c] += 1
                except: continue
        seed_str = f"{game_id}:{method}"
        seed_val = int(hashlib.md5(seed_str.encode()).hexdigest()[:8], 16) % 2**32
        rng = np.random.RandomState(seed_val)
        safe_rows = []
        for r in range(8):
            row_weights = heatmap[r]
            if method == 'booster':
                pred_col = np.argmin(row_weights + rng.rand(3) * 0.2)
            else:
                pred_col = np.argmin(row_weights + rng.rand(3))
            safe_rows.append(int(pred_col))
        return {"success": True, "safe": safe_rows, "confidence": round(float(rng.uniform(60, 75)), 2)}
    except:
        return {"success": False, "error": "Prediction Engine Error"}