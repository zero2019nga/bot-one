import numpy as np
import hashlib
import random
import json

def get_towers_prediction(method, game_id, history_str):
    try:
        heatmap = np.zeros((8, 3))
        if history_str:
            games = history_str.split('|')
            for g in games[:15]:
                try:
                    levels = json.loads(g)
                    for r, row_vals in enumerate(levels):
                        if r < 8:
                            for c, val in enumerate(row_vals):
                                if val == 1: heatmap[r][c] += 1
                except: continue
        safe_rows = []
        seed = int(hashlib.md5(f"{game_id}:{method}".encode()).hexdigest()[:8], 16) % 2**32
        rng = np.random.RandomState(seed)
        for r in range(8):
            row_weights = heatmap[r]
            if method == 'xgboost':
                pred_col = np.argmin(row_weights + rng.rand(3) * 0.2)
            elif method == 'lstm':
                pred_col = np.argmin(row_weights * 0.5 + rng.rand(3))
            elif method == 'ensemble':
                scores = (
                    (row_weights + rng.rand(3) * 0.2) +
                    (row_weights * 0.5 + rng.rand(3)) +
                    (row_weights + rng.rand(3))
                ) / 3
                pred_col = np.argmin(scores)
            else:
                pred_col = np.argmin(row_weights + rng.rand(3))
            safe_rows.append(int(pred_col))
        return {"safe": safe_rows, "confidence": round(float(rng.uniform(60, 75)), 2)}
    except:
        fallback_rng = np.random.RandomState(int(hashlib.md5(f"{game_id}".encode()).hexdigest()[:8], 16) % 2**32)
        return {"safe": [int(fallback_rng.randint(0, 3)) for _ in range(8)], "confidence": round(float(fallback_rng.uniform(60, 75)),